"""Optional adapter contract tests."""
