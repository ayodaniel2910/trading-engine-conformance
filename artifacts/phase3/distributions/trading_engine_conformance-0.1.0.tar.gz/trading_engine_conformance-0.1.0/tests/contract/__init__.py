"""Optional adapter contract tests."""
